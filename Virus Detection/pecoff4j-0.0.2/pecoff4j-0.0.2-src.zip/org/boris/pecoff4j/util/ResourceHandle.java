/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Peter Smith
 *******************************************************************************/
package org.boris.pecoff4j.util;

// Questions:
//   - how to handle named and id entries
//   - or the general case of a resource directory vs the
//     specific type,name,lang structure that is prevalent.
public class ResourceHandle {
}
